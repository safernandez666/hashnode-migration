---
title: "Centralizando Secretos con Hashicorp Vault"
date: "2021-03-10 20:25:56"
slug: "Centralizando Secretos con Hashicorp Vault"
image: "Insert Image URL Here"
---


¿Como hacer para que los secretos, que manejan nuestros DevOps, no qcapsvondutch andcamiciesaldi fracominaabiti diego-dalla-palma  legioiedigea lingerie  super sexy diegodellapalma blundstoneprezzi  von-dutch harmontblainescarpe  blundstoneoutlet  mandarinaducksaldi  von-dutch 24h-bottle marellaoutlet ueden en los servicios hardcodeados?. 



La solución es centralizarlos en Vault. Este manejara secretos estáticos y dinámicos. Vamos a explorar el concepto de "Encryption As a Service".



Vamos a utilizar Docker, para esta prueba. Vamos a crear las carpetas, que requerimos para la gestion del docker-compose.yaml.hawaiian prodotti solari&nbsp; kinderwagen peg perego pliko p3&nbsp; logitech dongle&nbsp; ציפוי מגנטי לדלתות&nbsp; разклонител пвц ппк ф40 ф40-87градуса&nbsp; oliver dragojevic majica&nbsp; dulap exterior dedeman&nbsp; przez te dresy zielone&nbsp; come pulire una caffettiera di alluminio&nbsp; כרית פריד קלאסיק&nbsp; sklopka za mješalicu betona&nbsp; prevent jacke&nbsp; dita logo משקפי שמש&nbsp; חזן צוקרמן שמלות כלה מחירים&nbsp; liu jo muske majice&nbsp;



sudo mkdir Vault/vault &amp;&amp; cd Vault/vault
sudo mkdir data policies logs config



Con la creación del Dockerfile &amp; el docker-compose.yaml quedaria de esta manera. 



santiago@ubuntu:~/Proyectos/Vault$ tree
.
├── docker-compose.yaml
└── vault
    ├── config
    │   └── vault-config.json
    ├── data
    ├── Dockerfile
    ├── logs
    └── policies




Creamos los archivos que nos estarían faltando. Por un lado el Dockerfile, que creara la imagen del container de Vault.



# Imagen Base
FROM alpine:3.11

# Agregamos la Ultima version. 
ENV VAULT_VERSION 1.6.3

# Creacion de Directorio
RUN mkdir /vault

# Descarga de Dependencias
RUN apk --no-cache add \
      bash \
      ca-certificates \
      wget

# Descarga de Vault y Configuracion
RUN wget --quiet --output-document=/tmp/vault.zip https://releases.hashicorp.com/vault/${VAULT_VERSION}/vault_${VAULT_VERSION}_linux_amd64.zip &amp;&amp; \
    unzip /tmp/vault.zip -d /vault &amp;&amp; \
    rm -f /tmp/vault.zip &amp;&amp; \
    chmod +x /vault

# Path
ENV PATH=&quot;PATH=$PATH:$PWD/vault&quot;

# Agregar Archivos de Configuracion
COPY ./config/vault-config.json /vault/config/vault-config.json

# Exponemos el Port 8200
EXPOSE 8200

# Run Vault
ENTRYPOINT [&quot;vault&quot;]



Dentro de config vamos a crear vault-config.json



{
    &quot;backend&quot;: {
      &quot;file&quot;: {
        &quot;path&quot;: &quot;vault/data&quot;
      }
    },
    &quot;listener&quot;: {
      &quot;tcp&quot;:{
        &quot;address&quot;: &quot;0.0.0.0:8200&quot;,
        &quot;tls_disable&quot;: 1
      }
    },
    &quot;ui&quot;: true
  }



Como pueden ver para esta prueba hemos creado el Vault en Backend, esto no es una buena practica. Aca les dejo un enlace para configuración, como corresponde, un Backend. Agregamos el listener y la interfaz UI.



Por ultimo el docker-compose.yaml.



version: '3.7'

services:

  vault:
    build:
      context: ./vault
      dockerfile: Dockerfile
    container_name: vault
    ports:
      - 8200:8200
    volumes:
      - ./vault/config:/vault/config
      - ./vault/policies:/vault/policies
      - ./vault/data:/vault/data
      - ./vault/logs:/vault/logs
    environment:
      - VAULT_ADDR=http://127.0.0.1:8200
      - VAULT_API_ADDR=http://127.0.0.1:8200
    command: server -config=/vault/config/vault-config.json
    cap_add:
      - IPC_LOCK



Vamos a crear ese container con docker-compose up -d --build y revisamos si esta corriendo con docker ps:



santiago@ubuntu:~/Proyectos/Vault$ docker-compose up -d --build
Building vault
Step 1/9 : FROM alpine:3.11
 ---&gt; 4666da2f166f
Step 2/9 : ENV VAULT_VERSION 1.4.0
 ---&gt; Using cache
 ---&gt; 28751b3bdd2a
Step 3/9 : RUN mkdir /vault
 ---&gt; Using cache
 ---&gt; 5add412a5e6d
Step 4/9 : RUN apk --no-cache add       bash       ca-certificates       wget
 ---&gt; Using cache
 ---&gt; 4ad54291195e
Step 5/9 : RUN wget --quiet --output-document=/tmp/vault.zip https://releases.hashicorp.com/vault/${VAULT_VERSION}/vault_${VAULT_VERSION}_linux_amd64.zip &amp;&amp;     unzip /tmp/vault.zip -d /vault &amp;&amp;     rm -f /tmp/vault.zip &amp;&amp;     chmod +x /vault
 ---&gt; Using cache
 ---&gt; 0d57364580a7
Step 6/9 : ENV PATH=&quot;PATH=$PATH:$PWD/vault&quot;
 ---&gt; Using cache
 ---&gt; 9c7f1ec59f98
Step 7/9 : COPY ./config/vault-config.json /vault/config/vault-config.json
 ---&gt; Using cache
 ---&gt; bfe379075af6
Step 8/9 : EXPOSE 8200
 ---&gt; Using cache
 ---&gt; 58279a7c4316
Step 9/9 : ENTRYPOINT [&quot;vault&quot;]
 ---&gt; Using cache
 ---&gt; 0ba547c00ab3

Successfully built 0ba547c00ab3
Successfully tagged vault_vault:latest
vault is up-to-date
santiago@ubuntu:~/Proyectos/Vault$ docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED              STATUS              PORTS                    NAMES
276bf9952c73        vault_vault         &quot;vault server -confi…&quot;   About a minute ago   Up About a minute   0.0.0.0:8200-&gt;8200/tcp   vault




Ya tenemos corriendo nuestro Vault para comenzar a gestionar nuestros secretos, estáticos &amp; dinámicos. Revisamos los logs, para poder iniciar nuestro Vault.



santiago@ubuntu:~/Proyectos/Vault$ docker-compose logs
Attaching to vault
vault    | ==&gt; Vault server configuration:
vault    | 
vault    |              Api Address: http://127.0.0.1:8200
vault    |                      Cgo: disabled
vault    |          Cluster Address: https://127.0.0.1:8201
vault    |               Listener 1: tcp (addr: &quot;0.0.0.0:8200&quot;, cluster address: &quot;0.0.0.0:8201&quot;, max_request_duration: &quot;1m30s&quot;, max_request_size: &quot;33554432&quot;, tls: &quot;disabled&quot;)
vault    |                Log Level: info
vault    |                    Mlock: supported: true, enabled: true
vault    |            Recovery Mode: false
vault    |                  Storage: file
vault    |                  Version: Vault v1.4.0
vault    | 
vault    | 2021-03-08T19:33:11.303Z [INFO]  proxy environment: http_proxy= https_proxy= no_proxy=
vault    | ==&gt; Vault server started! Log data will stream in below:
vault    | 




Vamos a conectarnos al Bash del contenedor para Inicializar el Vault con docker-compose exec vault bash y vamos a realizar estos comandos.



bash-5.0# vault operator init
Unseal Key 1: 9+Vd1eK/mU3wNUvyW08afht/HImvk7TQ24uo7ZRCLRbp
Unseal Key 2: rX/3vOqY9sfiWTcA2xcHg18yD/WtYwwjjUBBL2/E/3ft
Unseal Key 3: ZvcCCQtk9S0O+wikzpfZN36b4O9zLnDFWfuyrUE6epJ7
Unseal Key 4: qwboq8L9gLOkEJfRrmRxsxSgWN7cjx88lVc7cFt859kH
Unseal Key 5: SagtdjGSd4LJ+btbhFigmXJldDtJkVWetlJtFvZs/Deg

Initial Root Token: s.nFx20EKUhNbwBuhjjFIbQQf9

Vault initialized with 5 key shares and a key threshold of 3. Please securely
distribute the key shares printed above. When the Vault is re-sealed,
restarted, or stopped, you must supply at least 3 of these keys to unseal it
before it can start servicing requests.

Vault does not store the generated master key. Without at least 3 key to
reconstruct the master key, Vault will remain permanently sealed!

It is possible to generate new unseal keys, provided you have a quorum of
existing unseal keys shares. See &quot;vault operator rekey&quot; for more information.



Tome nota de las claves de apertura y del token root. Deberá proporcionar tres de las claves de apertura cada vez que se vuelva a sellar o reiniciar el servidor de Vault. ¡Arrancamos! Voy a copiar las 3 primeras. Para entender ¿porque 3 claves? ver este enlace.



bash-5.0# vault operator unseal
Unseal Key (will be hidden):
Key                Value
---                -----
Seal Type          shamir
Initialized        true
Sealed             true
Total Shares       5
Threshold          3
Unseal Progress    1/3
Unseal Nonce       4ebecbd8-126b-bb54-68fe-bdc0151ae02b
Version            1.6.3
Storage Type       file
HA Enabled         false
bash-5.0# vault operator unseal
Unseal Key (will be hidden):
Key                Value
---                -----
Seal Type          shamir
Initialized        true
Sealed             true
Total Shares       5
Threshold          3
Unseal Progress    2/3
Unseal Nonce       4ebecbd8-126b-bb54-68fe-bdc0151ae02b
Version            1.6.3
Storage Type       file
HA Enabled         false
bash-5.0# vault operator unseal
Unseal Key (will be hidden):
Key             Value
---             -----
Seal Type       shamir
Initialized     true
Sealed          false
Total Shares    5
Threshold       3
Version         1.6.3
Storage Type    file
Cluster Name    vault-cluster-3deaf32c
Cluster ID      ae759a82-deec-e0b5-97de-265c7bac6a6a
HA Enabled      false
bash-5.0#



¡Hecho! Ahora, usando el token root, podemos autenticarnos.



bash-5.0# vault login
Token (will be hidden):
Success! You are now authenticated. The token information displayed below
is already stored in the token helper. You do NOT need to run &quot;vault login&quot;
again. Future Vault requests will automatically use this token.

Key                  Value
---                  -----
token                s.nFx20EKUhNbwBuhjjFIbQQf9
token_accessor       KHACrJ4ej7gcw6c2JmQ30zD6
token_duration       ∞
token_renewable      false
token_policies       [&quot;root&quot;]
identity_policies    []
policies             [&quot;root&quot;]



Vault ahora está abierto y listo para usar.



Vamos a encender la Auditoria, para ello corremos este comando.



bash-5.0# vault audit enable file file_path=/vault/logs/audit.log
Success! Enabled the file audit device at: file/



Crear los secretos para asegurar nuestra aplicación Python. Para ello vamos a conectarnos a Vault, como ya sabemos y parametrizar las variables necesarias. Supongamos que necesitamos manejar el password de una API, en Flask &amp; Python, para que conecte a MySQL, ahí deberíamos usar el módulo de database para que Vault haga la gestión en la BBDD y la APP. Para esta PoC usaremos KV, ósea Key Value. Levantamos el plugin y agregamos un valor.



docker exec -it vault bash
bash-5.0# vault secrets enable kv
Success! Enabled the kv secrets engine at: kv/
bash-5.0# vault kv put kv/python password=tupassword
Success! Data written to: kv/python



Lo listamos o revisamos UI.



bash-5.0# vault kv get kv/python
====== Data ======
Key         Value
---         -----
password    tupassword



UI



¡Excelente! Ya tenemos el valor en Vault. Ahora veamos la utilización de la libreria HVAC para la gestion del mismo en Python. A fines practicos estoy hardcodeando las variables, que deberian de ser variables de entorno.



import os

import hvac
import json 

client = hvac.Client()
client = hvac.Client(
 #url=os.environ['VAULT_URL'],
 #token=os.environ['VAULT_TOKEN']
 url='http://192.168.0.209:8200',
 token=&quot;s.tSz4Yjr58lZFrsQQTwDDYyMA&quot;
)

json_formatted_str = json.dumps(client.read('kv/python'), indent=2)

print(json_formatted_str)

# Escribo Token con un Lease de 1 Hora
#client.write('kv/python', type='pythons', lease='1h')
# Imprimo Token
#print(client.read('kv/python'))



Simplemente voy a leer y a imprimir el JSON con el valor. 



Python



Hay muchas cosas por hacer, como utilizar Consul para el resguardo de las llaves, agregar SSL, revisar los plugins serán necesarios para las diferentes implementaciones. Espero les sirva y comiencen a investigar.

