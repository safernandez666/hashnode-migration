---
title: "Análisis DAST en nuestro Pipeline con OWASP ZAP"
date: "2020-07-06 23:46:56"
slug: "Análisis DAST en nuestro Pipeline con OWASP ZAP"
image: "Insert Image URL Here"
---


En esta entrada vamos a configurar OWASP ZAP en nuestro Pipeakuscarpe donkeywinkekatze 24bottles scarpeovye gabssaldi ynotborse corinne abbigliamento sexy borsalamilanesa maisenzashop saldibenetton donkeywinkekatze akutrekkingshop diego-dalla-palma fracominaoutlet gabssaldiline Jenkins. En esta ocasión no vamos a hacer una instalación de OWASP ZAP, vamos a ejecutarlo en un contenedor Docker en el mismo host que Jenkins y sumarlo al "Stage" a nuestro Pipeline.



Para comenzar, en el hoתנור בילד אין אייס מוצרי חשמל&nbsp; zasto su mini suknje seksi&nbsp; porto moniz madeira live webcam&nbsp; kärring moppe&nbsp; tutto echarpes feulles enfant&nbsp; can you connect usb microphone to soubd card&nbsp; puma basket trim block&nbsp; jimmy hex tricouri&nbsp; bioscalin nutricolor prezzo&nbsp; zasto su mini suknje seksi&nbsp; חנות צילום ופיתוח תמונות באזריאלי&nbsp; nike tennis herren&nbsp; haider maula mp3&nbsp; accessori moda menesello&nbsp; vesta kožešinová&nbsp;st que contiene Jenkins, vamos a correr el Docker de OWASP ZAP.



docker run --detach --name zap -u zap -v &quot;/opt/dast/reports&quot;:/zap/reports/:rw \
  -i owasp/zap2docker-stable zap.sh -daemon -host 0.0.0.0 -port 8080 \
  -config api.addrs.addr.name=.* -config api.addrs.addr.regex=true \
  -config api.disablekey=true



Como ven el tag -v apunta a una carpeta nuestro SO, para poder depositar los reportes que generemos. 



Vamos a hacer una llamada directa al Docker con el comando zap-cli. Elegí el quick-scan y agregamos un tag de Medium. La finalidad es que no me reporte los Low.



docker exec zap zap-cli --verbose quick-scan http://pipeline.ironbox.com.ar:8090 -l Medium



Vamos a crear un Stage en nuestro código Groovy de Jenkins. Agregue un Try &amp; Catch. Me interesa, por los falsos positivos, que el Pipeline continue aun si tenemos vulenrabilidades Medium o High.



A continuación creamos el reporte. En este caso, para su posterior publicación, la salida es html pero podríamos jugar con otros formatos para alimentar otro sistema. Por ejemplo JSON para utilizar ArcherySec o DefectDojo y poder gestionar la vulnerabilidad hallada. 



        stage('DAST') {
            steps {
                script {
                    try {
                        echo &quot;Inicio de Scanneo Dinamico&quot;
                        sh &quot;docker exec zap zap-cli --verbose quick-scan http://pipeline.ironbox.com.ar:8090 -l Medium&quot; 
                        //sh &quot;docker exec zap zap-cli --verbose alerts --alert-level Medium -f json | jq length&quot;
                        currentBuild.result = 'SUCCESS' 
                    }
                    catch (Exception e) {
                            //echo e.getMessage() 
                            //currentBuild.result = 'FAILURE'
                            println (&quot;Revisar Reporte ZAP. Se encontraron Vulnerabilidades.&quot;)

                        }
                    }  
                    echo currentBuild.result 
                    echo &quot;Generacion de Reporte&quot;
                    sh &quot;docker exec zap zap-cli --verbose report -o /zap/reports/owasp-quick-scan-report.html --output-format html&quot;
                    publishHTML target: [
                        allowMissing: false,
                        alwaysLinkToLastBuild: false,
                        keepAll: true,
                        reportDir: '/opt/dast/reports',
                        reportFiles: 'owasp-quick-scan-report.html',
                        reportName: 'Analisis DAST'
                      ]          
            }
        }



¡Vamos a correr ese Pipeline! A ver que nos entrega.



Pipeline OWASP ZAP



Como habíamos configurado el Pipeline continuo aun habiendo encontrado una vulnerabilidad Medium.



Ahora podemos revisar el reporte.





Reporte ZAP



Muchas cosas para configurar y seguir jugando. Espero que les sea de utilidad.



¡Nos vemos en la próxima entrada!

