---
title: "Acceso Seguro a nuestro servidores SSH via Teleport"
date: "2021-12-12 22:10:44"
slug: "Acceso Seguro a nuestro servidores SSH via Teleport"
image: "Insert Image URL Here"
---


Teleport es un Gateway para asegurar acceso remotos a servidores Linux o la API descarpeovye benettonoutlet air max  goaterra 2.0 completini  intimi molto sexy chilloutshut akuscarpe saldigeox kleankanteentrinkflasche  andcamicienegozi  gabsoutlet guardianialberto  scarpeovye chilloutsmutze akuschuhe borsegabsoutlet  Kubernetes. Esta destinado a ser usado en lugar de OpenSSH para organizaciones que necesiten proteger su infraestructura, cumplir con las mejores practicas de seguridad y los requerimientos de compliance. Nos ayuda a tener visibilidad completa de la actividad que ocurre en la arquitectura, reduciendo el tiempo operativo de la administración de acceso privilegiado sea en la suport telefon auto allview  marine stickers for boat  מחסני חשמל מבצעים באר שבע מכונת כביסה  kärring moppe  hp מדפסת פשוטה  pantalon chino homme skinny  igi e co sneakers alte amazon  nike free x metcon 2 vs metcon 5  מזוודות קשיחות קופון  детски фолклорни музикални инструменти  3060 ti  אקווריום 250 ליטר  aloe vera gel da bere in farmacia amazon  מעבד gb ram  τα παπουτσια του προσφυγα nube o en On Premises. 



Teleport tiene como objetivo ser un proxy ssh y nos trae el concepto de entorno en lugar de servidores. 



Características




Un solo Gateway para acceso SSH o Kubernetes, para toda la organización.



Autenticación basada en certificados, en lugar de claves estáticas. 



Nos evita la distribución de claves. Las llaves entregadas tienen caducidad automatica por la autoridad certificadora ( CA ).



Conectarse a clusters ubicados por detrás de firewalls sin acceso directo a internet través de bastiones SSH. 



Capacidad de gestionar la confianza entre equipos, organizaciones y centros de datos.



Acceso SSH / Kubernetes a enternos sin necesidad de puertos abiertos. 



Control de Acceso basado en Roles ( RBAC ).



Unica herramienta para administrar los accesos.



Registros de Auditoria y Grabación de sesiones. 




¿Como funciona?



Teleport How to?



Vamos a configurar nuestro acceso SSH al master del cluster Kubernetes. En otra entrada haremos la configuración a la API de Kubernetes para interactuar con kubectl. Para esto necesitaremos un servidor con el servicio SSH y un servidor, con Teleport, que hara de Proxy | PAM al servicio. 



Mi escenario es el siguiente. Tengo 3 servidores, con Ubuntu 20.04:



master.local192.168.205.138worker01.local192.168.205.139teleport.local192.168.205.135Tabla



Si no sabes como instalar un cluster de Kubernetes, te dejo este articulo. 



Cluster Kubernetes



Para instalar teleport en Ubuntu, podes hacerlo de esta manera.



Generación de Usuario



Lo primero que tenemos que hacer es crear el usuario en nuestro servidor para comenzar las configuraciones. Vamos a usar el siguente comando, dentro del servidor de teleport.



sudo tctl users add teleport-ssh  --roles=editor,access --logins=root,santiago



Creamos el usuario teleport-ssh con roles de editor y acceso, donde solo podrá loggearse con root y santiago.



tluser



Con la URL que nos entrega terminamos de generar el usuario, para ello tenemos una hora. Sera necesario contar con un dispositivo móvil para configurar el MFA. En mi caso usare Authy.



Portal de Login



Una vez loggin on, revisamos la consola y vemos nuestro usuario. Teleport siempre impondrá el uso de autenticación de dos factores de forma predeterminada. Admite contraseñas de un solo uso (OTP) y tokens de hardware (U2F). Este inicio rápido utilizará OTP; necesitará una aplicación compatible con OTP que pueda escanear un código QR.



usuario teleport-ssh



Logging con Cliente tsh



Tenemos que instalar la maquina cliente para poder interactuar con nuestro Jump Server. Para ello debemos seguir este tutorial. 



Vamos a probar nuestro login a teleport. Luego agregaremos un nodo, en este caso el master de Kubernetes. 



Login



Agregando un Nodo



Nos autenticamos en nuestro master de Teleport para generar el token de Join. 



sudo tctl tokens add -type=node --ttl=1h 



tctl tokens



Ahora nuestro master node de Kubernetes es parte de la granja de teleport.



Join Server



Revisamos en la GUI



Nodos



Hacemos el logging SSH via tsh.



tsh login



Revisamos la auditoria...



Auditoria



Esto es todo por ahora. Es una herramienta interesante para auditar a terceros o los mismos administradores de nuestro entorno. Les recomiendo leer la documentación para grabar sesiones y otras características. En la proxima entrada agregaremos la API de Kubernetes. ¡Espero les sirva!

