---
title: "Cloud Custodian el CSPM Open Source"
date: "2023-06-11 19:40:35"
slug: "Cloud Custodian el CSPM Open Source"
image: "Insert Image URL Here"
---


Muchas veces me consultan sobre el Cloud, como asegurarlo. Siempre aconsejo herramientas como Prisma Cloud o AquaSec, dependiendo la inversion que se quiera o pueda erogar. Ahora: ¿Existen alternativas?, la respuesta es Si! Para eso existe Cloud Custodian. 



Primero, ¿Que es un CSPM o Cloud Security Posture Managment? Es un conjunto de herramientas, practicas que nos dan una mano para evaluar, identificar y resolver errores de configuración, algún desvio en el cumplimiento o riesgos de seguridad. Hoy, por hoy, una herramienta fundamental en todo ambiente Cloud. 



¿Que beneficios acarrea implementar un CSPM?



Tareas:




Realización de escaneo continuo y determinación de la postura de seguridad en tiempo real.



Permite a una organización obtener una visibilidad continua en todo el&nbsp;infraestructura de nube.



Detección automática y corrección de configuraciones incorrectas y problemas de cumplimiento



Realizar evaluaciones comparativas y auditorías de cumplimiento para garantizar que la organización siga las mejores prácticas.




Tipicamente actua de la siguiente manera:




Supervise continuamente el entorno y los servicios de la nube y proporcione una visibilidad completa de los componentes y las configuraciones.



Compare las configuraciones y políticas de la nube con un conjunto de pautas aceptables.



Detecte errores de configuración y cambios de política.



Identificar amenazas existentes, nuevas y potenciales.



Corrija las configuraciones incorrectas en función de las reglas preconstruidas y los estándares de la industria. Esto ayuda a reducir los riesgos debido a errores humanos que podrían resultar en configuraciones incorrectas.




¿Que es Cloud Custodian?



Lanzado en 2016, soportado por CNCF, esta herramienta escrita en Python fue desarrollada por la gente de Capital One. Basicamente es un motor de reglas para el manejo de cuentas de Cloud o el gobierno de recursos. Utiliza manifiestos en YAML que componen la politica a aplicar. Vamos a realizar algunos ejemplos, pero tienen que tener en mente que consta de Recursos O Servicios, donde vamos a realizar la magia, Filtros &amp; Acciones. Puede sacarnos dolores de cabeza en varios dominios. Entre las características mas interesantes nos encontramos que es Agentless &amp; multicloud.  







Prueba de Concepto



Vamos a poner manos a las obra. El primero caso de uso, que quiero hacer con uds. es el siguiente. Vamos a trabajar sobre AWS, apagando los ambientes de testing. Algo que la gente de FinOps, nos agradecera a la hora del billing. 



Instalar Cloud Custodian



Yo uso Mac, en este caso, por ende:



python3 -m venv custodian
source custodian/bin/activate
pip install c7n 



Si vas a trabajar con otra plataforma, te dejo este enlace a la documentación oficial. 



Creación de Usuario en AWS &amp; Rol



Vamos a crear nuestro user cloudcustodian, darle acceso a EC2 y generar nuestras credenciales programáticas para accesar a AWS. Si no sabes como crear usuarios e instalar el cliente programático de AWS, revisa los links de fuentes. 



Para fines prácticos, agregue le Rol AmazonEC2FullAccess, algo que tienen que revisar por el principio de "Least Privilege".







Vamos a preparar el ambiente, generando una instancia EC2 con el tag de testing. Con eso estaremos listo para probar nuestra primer politica. 







Ahora vamos a revisar nuestra politica. Pero antes quiero mostrarle los comandos para conocer sobre que recursos o servicios podemos trabajar, los filtros que podemos utilizar y las acciones. Para ello utilizaremos los comandos custodian schema, custodian schema ec2.filters &amp; custodian schema ec2.actions.Vamos a la politica, para ello creamos ec2-policy.yaml. Es muy sencilla de leer, primero el recurso que queremos modificar, luego el filtro y por ultimo la acción. En nuestra politica no solo paramos la instancia, si no tambien que renombramos el tag. 







Vamos a correr la politica, pero antes vamos a validarla. Para ello usaremos estos dos comandos: custodian validate y custodian run. En el run agregue el directorio para el output y tambien el flag --verbose para ver el paso a paso o en su defecto debbugear. 







Uala! Revisamos los pasos, primero comenta que encontro 1 recurso con esa condición, después paro la instancia y luego modifico el tag. Vamos a revisarlo!







Vamos a revisar otro caso de uso y agregar una integración con Slack via c7n-mailer. La arquitectura es la siguiente c7n-mailer crea una Lamdba Function y una CloudWatch Event Rule en tu cuenta de AWS. Esa regla se dispara cada 5 minutos. La Lambda leerá el SQS para ver si tenemos o no mensajes, procesarlo y enviar la notificación. Si llegaste hasta aca es por que sabes que vamos a tener que agregar nuevos parametros a la politica del tipo notify.







Vamos a ejecutar:



pip install c7n-mailer







Generamos nuestro archivo mailer.yaml con la dirección de la cola SQS y a nuestro usuario le agregamos propiedades para que pueda leer la cola. Nos deberia quedar algo asi.









Ahora vamos actualizar la configuración con el siguiente comando. 



c7n-mailer --config mailer.yaml --update-lambda



Es importante que el Rol tenga los derechos sobre Lambda, SQS, Cloudwatch para poder funcionar. Revisamos nuestra lambda!







Vamos agregar la acción a nuestra politica.







Ya tenemos avisos en nuestro channel de Slack. Aca podes saber como generar un webhook. 







Las posibilidades son infinitas, solo revisar los documentos que hay en internet o la misma web oficial. Custodian puede trabajar con Security Hub, integrar con notificaciones o por que no generar un Dashboard en nuestro SIEM. A revisar!



Fuentes



https://docs.aws.amazon.com/IAM/latest/UserGuide/id_users_create.html



https://geekflare.com/es/cloud-security-posture-management/https://dev.to/sivatharsan/multi-account-security-governance-as-code-with-cloud-custodian-on-aws-organization-hl8



https://medium.com/@abhinav__singh/slack-integration-with-cloud-custodian-66d33ae19908

