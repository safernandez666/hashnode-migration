---
title: "Análisis de Código en CI/CD con SonarQube. Parte 1."
date: "2019-12-22 23:24:05"
slug: "Análisis de Código en CI-CD con SonarQube. Parte 1."
image: "Insert Image URL Here"
---


La creación de un Ciclo de Vida de Desarrollo de Software seguro (sSDLC) está empezando a convertirse en una de las formas más completas de asegurar el desarrollo seguro de aplicaciones web y móviles. En un escenario de Integración Continua y Entrega Continua (CICD) podríamos utilizar SonarQube en nuestros Pipelines, para realizar los análisis de código de una manera automatica.



En esta primera parte vamos a instalar un servidor de SonarQube sobre Ubuntu 18.04. 



Creamos el usuario.



sudo useradd -M -r -s /usr/sbin/nologin sonar



Vamos a instalar Java y algunos paquetes necesarios.



sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install unzip wget net-tools openjdk-8-jre -y



Ya hemos instalado los componentes y tenemos el usuario creado, sin shell, para sonar. Vamos a instalar nuestra base de datos Postgresql. Las nuevas versiones de SonarQube han deprecado el soporte a MySQL.



sudo apt-get update
echo &quot;deb http://apt.postgresql.org/pub/repos/apt/ $(lsb_release -cs)-pgdg main&quot; &gt; /etc/apt/sources.list.d/pgdg.list
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add - 
sudo apt-get update 



Procedemos a la instalación, en mi caso voy a ir por la version 11.



sudo apt-get install postgresql-11 -y



Ingresamos a Postgresql y creamos el usuario de Base de Datos. Tambien lo llamamos 'sonar'.



su - postgres
createuser sonar



Creamos una base de datos y hacemos que el usuario 'sonar' sea el propietario de esa base de datos.



psql
ALTER USER sonar WITH ENCRYPTED password 'TUPASSWORD';
CREATE DATABASE sonar OWNER sonar;



Vamos a descargar SonarQube. Voy a instalar la version 7.5, no es la ultima, que es compatible con Java 8.



wget https://binaries.sonarsource.com/Distribution/sonarqube/sonarqube-7.5.zip



Descomprimimos y ubicamos en la carpeta /opt/ para luego crear la carpeta /opt/sonar.



sudo unzip sonarqube-7.5.zip -d /opt/
cd /opt
sudo mv sonarqube-7.5 sonar



Vamos a darle derechos a 'sonar' a la carpeta /opt/sonar, recién creada.



sudo chown -R sonar:sonar /opt/sonar



Ahora vamos a configurar SonarQube, tenemos que agregar algunas lineas en /opt/sonar/conf/sonar.properties. Entre ellas el usuario y password de Base de Datos, el puerto que vamos a consultar y desde donde se podrá consultar. 



sonar.jdbc.username=sonar
sonar.jdbc.password='TUPASSWORD'
sonar.jdbc.url=jdbc:postgresql://localhost/sonar
sonar.web.javaAdditionalOpts=-server
sonar.web.port=30000
sonar.web.host=0.0.0.0



De esta manera ya lo vamos a tener configurado para que trabaje en el puerto 30000, en localhost, y podrá accederse de cualquier lugar. Si llegaríamos a poner un Proxy Reverso, como Nginx o Apache, seria importante cambiar el 0.0.0.0 por 127.0.0.1.



Vamos a crear el archivo para manejar el servicio. Creamos /etc/systemd/system/sonar.service y copiamos lo siguiente.



[Unit]
Description=SonarQube service
After=syslog.target network.target

[Service]
Type=forking

ExecStart=/opt/sonar/bin/linux-x86-64/sonar.sh start
ExecStop=/opt/sonar/bin/linux-x86-64/sonar.sh stop

User=sonar
Group=sonar
Restart=always

[Install]
WantedBy=multi-user.target



Ultimos retoques para levantar el servicio.



sudo systemctl daemon-reload
sudo systemctl enable sonar
sudo systemctl start sonar &amp;&amp; systemctl status sonar



Vamos ver si estamos en linea. Hacemos un:



curl http://127.0.0.1:30000



Nos debería salir algo asi:



curl



Ya podríamos verlo en nuestro navegador.



http://127.0.0.1:30000



En la próxima entrada conectaremos Jenkins, via Sonar Scanner, para realizar un relevamiento de Código sobre Python. 

