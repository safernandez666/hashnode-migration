---
title: "Enviando nuestros Log's, de Windows, a Graylog2."
date: "2019-03-17 16:07:08"
slug: "Enviando nuestros Log's, de Windows, a Graylog2."
image: "Insert Image URL Here"
---


Graylog es un SIEM libre y abierto, donde centralizaremos todos los log's de nuestro entorno sobre MongoDB&nbsp;y&nbsp;Elasticsearch. Usando Graylog podemos, de una manera fácil, recolectar y analizar los Log's de todos nuestros servidores. Elasticsearch almacenara nuestros log's y nos proporcionara maneras sencillas de buscar en ellos. MongoDB guardara nuestras configuraciones y meta data. Graylog recolectara todos estos log's, a través de inputs, y nos dará una interfaz Web para su manejo. 



Arquitectura



Para esta prueba de concepto, nuestra infraestructura sera la siguiente:



Graylog Server | Ubuntu 18.04Windows Server 2012 R2graylog.ironbox.local AD01.ironbox.local10.0.2.2010.0.2.19



Arquitectura



Dejaremos la configuración, de Linux, para una próxima entrada.



Instalación de Graylog 



Vamos a comenzar con la instalación de nuestro SIEM sobre nuestro Ubuntu 18.04.



Actualización del Servidor



Actualizamos e instalamos Java con otros componentes.



Actualización e Instalación de Paquetes.



Vamos a comprobar la versión de Java. 



Comprobamos Java



Instalación de Elasticsearch



Elasticsearch es uno de los componentes principales que requiere que Graylog se ejecute, actúa como un servidor de búsqueda, ofrece una búsqueda distribuida en tiempo real y análisis con la interfaz web RESTful.



Elasticsearch almacena todos los registros enviados por el servidor de Graylog y muestra los mensajes cada vez que el usuario lo solicita a través de la interfaz web incorporada.



Descargamos e instalamos la clave de firma GPG.



Instalación de Elasticsearch



Vamos a hacer que Elasticsearch inicie en el Boot y configuramos el cluster.name.







Debería quedarnos, de esta manera.



Edicion de Elasticsearch



Vamos a reiniciar, la nueva configuración y revisar si nos responde! Deberíamos de tener como claster.name graylog y el status en Green. Lo revisamos.



Chequeos



Instalación de MongoDB



Graylog usa MongoDB para almacenar sus datos de configuración, no sus datos de registro. Solo se almacenan los metadatos, como la información del usuario o las configuraciones de flujo.









Instalación de Graylog



Graylog Server acepta y procesa los mensajes de registro y luego los muestra para las solicitudes que provienen de la interfaz web de graylog. Descargue e instale el repositorio graylog 3.x. 







 Configuración Graylog 



Debe establecer un secreto para proteger las contraseñas de usuario. Usa el comando pwgen para el mismo y pasamos por SH256sum el que sera nuestra contraseña para admin.



Configuración de Graylog. Contraseñas y http_bind_address.



Reiniciamos y configuramos para que se inicie automáticamente. Revisamos los log's hasta tener nuestro servidor en linea.



Inicio Automático de Graylog.



 Configuración de Windows Server 2012 R2 



Descargamos el NXLog, desde su&nbsp;web.



Instalamos en Windows y vamos a configurar el archivo&nbsp;nxlog.conf&nbsp;que se encuentra en&nbsp;C:\Program Files (86x)\nxlog\conf\



Vamos a prestar atención a 2 lineas. La primera, donde se define la ruta del software y la segunda, la dirección TCP donde enviaremos los eventos. Osea la dirección de nuestro servidor Graylog.



Configuración NXLog



Vamos a configurar la Auditoria, de Windows, para poder observar el ABM de cuentas, como los Logon y Logoff. Para ello vamos a ir a Local Security Policy.



Local Security Policy



Hacemos Inicio &gt; Ejecutar &gt; services.msc e iniciamos NXLog.



Reinicio de NXLog



Solo nos queda configurar el INPUT, en Graylog, para que comience a recibir los Log's. Siguiendo nuestra configuracion, de NXLog, vamos a crear un INPUT en el puerto 12201, GELF UDP.



GELF UDP | Puerto 12201



Vemos que empiezan a fluir los Log's.



Dashboard



En el&nbsp;Market Place de Graylog, podrán encontrar interesantes Dashboard's armados por la comunidad.



Aquí les dejo un&nbsp;PDF, interesante, para configurar Windows.



Vamos a instalar este Content Pack. Con las funciones, vitales, de Active Directory. En esta PoC, creamos una cuenta para verla reflejada en nuestro Dashboard. 



Dashboad



Picamos en AD User Object Summary, donde tendremos un snapshot de todos los datos de ABM en Active Directory.



Creación de Usuario



Seguiremos sumando INPUT's a nuestro SIEM. Un componente, vital, para nuestro día a día y para también hacer frente a auditorias!



Cualquier, duda, no duden en escribirme! Les comparto los comandos, en un TXT, y el archivo de configuración de NXLog.



Les dejo los comandos, de Instalación, para que puedan hacer copy / paste.



Hasta la próxima!

