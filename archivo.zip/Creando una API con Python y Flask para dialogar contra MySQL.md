---
title: "Creando una API con Python y Flask para dialogar contra MySQL"
date: "2019-03-04 19:49:09"
slug: "Creando una API con Python y Flask para dialogar contra MySQL"
image: "Insert Image URL Here"
---


En esta ocasión vamos a crear una API, como dice el titulo, para interactuar con nuestra base de datos MySQL. La idea es poder agregar, modificar o eliminar registros a través de nuestra API (Application Programming Interface). Para ello utilizaremos Python y Flask que es un “micro” Framework concebido para facilitar el desarrollo de Aplicaciones Web. Ademas utilizaremos Flask-SQLAlchemy una herramienta hecha en Python, que es un Toolkit y ORM que da a los desarrolladores poder total y flexibilidad sobre SQL junto con Flask-marshmallow que convertirá los objetos ORM en JSON.



Vamos a crear una base de datos, en MySQL, con las siguientes tablas. Las mismas se crearan automáticamente por ORM. Esta sera la estructura, de la tabla.



Base de Datos test_api con la tabla user.



Acá un bosquejo de la arquitectura, con sus diferentes componentes. 







Instalación de Componentes



Podemos instalar Flask-SQLAlchemy y  Flask-marshmallow de una manera sencilla, utilizando pip. Antes que nada, hacemos un update &amp;&amp; upgrade, de nuestro sistema. En mi caso voy a realizar la PoC con Ubuntu Server.



Instalación de Componentes



Vamos a instalar la base de datos MySQL junto con las librería de Python. Para estos fines, didácticos, voy a permitir todo. Sera necesario crear una base de datos, yo la llamo test_api, para que flask_sqlalchemy cree las tablas, necesarias, en base a los parámetros que indicaremos, mas adelante, en el código. 



Instalación y Configuración de MySQL.



Creación del Código



Ya tenemos todo preparado. Vamos a comenzar con el código, aquí les dejo el repositorio en GitHub. Veamos el proyecto, completo, pero vamos a desmenuzarlo un poco, mas adelante.







En la primer parte veremos las librerías, necesarias, como también la configuración a Base de Datos. Les dejo, comentada, la de SQLite. La idea era realizarla con MySQL por la cantidad de proyectos en la que nos podemos encontrar con ella.



Librerías y Configuraciones



En la siguiente parte, vemos como declaramos un modelo llamado User y definimos su campos con sus propiedades.



Modelo y Schem



En el código, restante, nos encontraremos con las rutas necesarias para gestionar la Base de Datos.



Vamos a verlo trabajar, con los diferentes verbos HTTP. Voy a describir los pasos, para luego verlos del lado del Servidor y del Cliente.



Listar los usuarios. "GET"Agregar Usuarios. "POST"Modificar Usuario, por ID. "PUT"Eliminar Usuario, por ID. "DELETE"



Servidor API en Ubuntu, mediante SSH.



Acá los comandos cURL, para la gestión de la base por HTTP.



Ejecución vía cUrl



Por ahora esto es todo. Espero que les sirva. En la próxima parte, vamos agregarle seguridad.



Saludos! 

