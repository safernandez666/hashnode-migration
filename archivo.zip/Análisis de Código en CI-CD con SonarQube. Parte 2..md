---
title: "Análisis de Código en CI/CD con SonarQube. Parte 2."
date: "2019-12-26 00:54:25"
slug: "Análisis de Código en CI-CD con SonarQube. Parte 2."
image: "Insert Image URL Here"
---


Ya tenemos nuestro servidor de SonarQube funcionando, en base al primer tutorial. Ahora nos queda hacerlo formar parte de nuestro Pipeline.  Lo primero que debemos hacer es instalar, en Jenkins, sonar-scanner. Para ello vamos a conectarnos, via SSH, e instalarlo.



Aca les dejo para realizar la descarga y la documentación oficial.



¡Realizamos los siguientes comandos!



wget https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-4.2.0.1873.zip
unzip sonar-scanner-cli-4.2.0.1873.zip
mv sonar-scanner-cli-4.2.0.1873-linux /opt/sonar-scanner 



Configuramos sonar-scanner. Para ello en /opt/sonar-scanner/conf/sonar-scanner.properties, agregamos la dirección de nuestro SonarQube.



#Configure here general information about the environment, such as SonarQube se&gt;
#No information about specific project should appear here

#----- Default SonarQube server
sonar.host.url=http://DIRECCIONDELSERVIDORSONARQUBE:30000

#----- Default source code encoding
#sonar.sourceEncoding=UTF-8



Ingresamos en Jenkins para la instalación del PlugIn.



Manage Jenkins&nbsp;&gt;&nbsp;Manage Plugins&nbsp;&gt;&nbsp;Avalable&nbsp;&gt;&nbsp;SonarQube scanner



Configuramos el PlugIn, indicando la ruta de sonar-scanner.



Manage Jenkins&nbsp;&gt;&nbsp;Global Tool Configuration&nbsp;&gt;&nbsp;SonarQube Scanner



PlugIn



Tenemos que configurar el Token de Autenticación. Para ello, primero, debemos ingresar a SonarQube, por defecto el usuario y contraseña es admin/admin. Una vez autenticados:  



Generación de Token



¡Lo copiamos!



Copiamos el Token.



Ya con el Token, volvemos a configurar Jenkins. 



Manage Jenkins&nbsp;&gt;&nbsp;Configure Systems&nbsp;&gt;&nbsp;SonarQube Servers







Dependiendo de la version de Jenkins, que esten utilizando, tengan que agregar el Token como Secret Text.



Llego el momento de crear la Tarea. En mi caso vamos a revisar el código de  un proyecto, sencillo, en Python. Importante revisar en el MarketPlace, de SonarQube, si tenemos el PlugIn del lenguaje a auditar.



Configuramos el Source, del proyecto:







Agregamos las variables de SonarQube, para la conexión y la creación del proyecto.







¡Ejecutamos! Al finalizar, si obtuvimos Success, podríamos chequear los Issues del código. Con esa información disparar resoluciones, bloquear el deploy, etc. Todo se basara en las configuraciones de nuestro Quality Gates. 



Success Jenkins Task



Vemos el reporte del Job proyectKey







Podemos ver las recomendaciones que nos otorga SonarQube.



Seguramente tengamos mucho para mejorar u optimizar. ¡Espero que les sirva!





