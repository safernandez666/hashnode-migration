---
title: "API RESTful Serverless en Lambda y MySQL"
date: "2019-04-24 18:42:07"
slug: "API RESTful Serverless en Lambda y MySQL"
image: "Insert Image URL Here"
---


Vamos a implementar un API RESTful en Serverless, en otras palabras sin utilización de servidores, como los conocemos. Existen muchos proveedores que ofrecen servicios, sin servidor, pero vamos a quedarnos con Amazon Web Services.



Si no conocen el termino Serverless es buen momento para empezar a investigarlo y empaparnos de su uso.



Arquitectura



Aca un bosquejo de la arquitectura, que utilizaremos, donde tenemos las diferentes funciones Lambdas que eran invocadas desde nuestro API Gateway. 



API Gateway invocan a las Funciones Lambda, que se conectan contra la Base de Datos RDS MySQL



Vamos a usar Serverless Framework que nos dará la posibilidad de manejar, localmente, nuestro código para probarlo y a su vez hacer el deploy, de nuestro código, con la configuración del entorno. Automáticamente, tendremos, parametrizada nuestras rutas en el API Gateway.



EndPointMétodoDescripción1/usuarioGETLista todos los usuarios de la tabla2/usuario/{id}GETLista el usuario, especifico.3/usuarioPOSTCrea un nuevo usuario en la tabla4/usuario/{id}PUTModifica un usuario existente5/usuario/{id}DELETEElimina un usuario



Para esta PoC sera necesario tener instaladas las siguientes herramientas y framework's.



Recursos



Node.js 8.10.MySQL, Instancia RDS en AWS.Editor de Código.Postman.



Para crear la Base de Datos, en AWS RDS, podemos revisar este articulo donde se crea una instancia. Es importante que tengamos su FQDN, Nombre de Instancia, Usuarios y Password. 



Vamos a crear la Base de Datos, donde trabajaremos, en MySQL, luego de conectarnos. 



CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;



Serverless Framework



Vamos a instalar Node.js en nuestro equipo, puede variar segun nuestro sistema operativo y serverless. 



Llegó el momento de agregar nuestras credenciales de AWS. Acá les dejo un documento, para crear un perfil IAM. En mi caso, cada perfil tiene sus credenciales. En mi caso ~/.aws/credentials



Perfiles de AWS



Creamos una carpeta y los archivos necesarios de Node.js y Serverless para comenzar!



Creación de Carpeta y Template



Template Serverless



Vamos a pegarle una mirada a nuestro serverless.yml. 



Serverless.yml



Vamos agregarle el perfil, que usaremos, para hacer el deploy y la region donde queremos hacerlo.



Profile &amp; Region



Instalamos las dependencias. Por un lado serverless-offine, para las pruebas locales, junto con MySQL, para la conectar la base de datos, y querystring, para el parseo de los JSON. Luego inicializamos nuestro archivo.



Dependencias e Inicialización



Creamos el archivos connections.js donde pondremos todos nuestros datos de conexión. Vamos a AWS RDS y en base a la BBDD cargamos las variables para su funcionamiento.



connections.js



Creamos la carpeta CRUD/usuarios.js, donde estarán los handlers que atenderán las llamadas de nuestros Endpoints.



crud/usuarios.js



Ahora nos toca crear los Endpoints, en el YAML. Aca les dejo mi serverless.yml.



Endpoints



Ya tenemos todo listo para subirlo a AWS! Serverless creara el API Gateway, las funciones Lambda automaticamente! Hacemos: 



sls deploy



En el supuesto caso de querer probar, localmente, podríamos haber utilizado sls offline para la prueba local. Logicamente con los direccionamientos, correspondientes, de base de datos del archivo connections.js.



Deploy



Empezo la Magia!







Aca podemos ver, varias cosas:



Si revisamos el S3 Bucket, encontraremos nuestro código. A su vez se crearan las funciones y las rutas en el Gateway. 



Funciones Lambda



Lambda



API Gateway







Consumo de la API



Vamos a jugar, con POSTMAN, para revisar nuestras API's.



Creamos 1 registro, para ello utilizaremos el verbo POST junto al envio del JSON, con los datos a insertar.



POST create



Vamos a realizar un GET junto con el ID.



Get findOne



Probamos de traer todos los registros.



GET findAll



Vamos a eliminar el registro.



DELETE delete



Espero que les sirva! Les dejo el proyecto en GitHub.



En la próxima entrada, vamos a darle seguridad! Si quieren eliminar, de sus cuentas, el deploy no tienen mas que hacer sls remove.



Saludos!

