---
title: "Organizando la Nueva Seguridad Agil: Spotify + Security Champion"
date: "2019-09-09 22:44:28"
slug: "Organizando la Nueva Seguridad Agil: Spotify + Security Champion"
image: "Insert Image URL Here"
---


Hace unos meses tome la decisión de cambiar de aires, cambiar de compañía. Hacia un tiempo que estaba en búsqueda de un desafío, algo que me mejore como profesional. Que me eleve. Sin duda alguna cuando elegimos esta carrera – informática – sabemos que vamos a tener que estar en un proceso de mejora continua, constante. Si bien he estado en procesos Agile, algo que ha llegado para quedarse en vísperas de suplantar los modelos traiciónales de gestión, hoy me encuentro en un reto a escala. Un duelo que tiene como contrincante asegurar mas de 20 Squad’s. Que son pequeños equipos de entre seis y ocho personas con perfiles multidisciplinarios que tienen que llevar a cabo una misión utilizando la metodología Scrum.



Mientras escribo intento hacer un bosquejo, en mi cabeza, de como explicar todo lo aprendido o como trasladar la manera de abordar la seguridad en un contexto Ágile, a escala, donde aparecen tecnologías y maneras de hacer las cosas de un tipo diferente al viejo Waterfall.



Si sos de Seguridad, como yo, sabes que siempre - o casi llegamos al final. Nuestra primera acción, sin dudas, es evangelizar. Hacer el “Shift Left” de la Seguridad. Debemos estar al comienzo del proyecto, en las primeras iteraciones. Hacerle comprender al negocio que no somos un “freno de mano”, sino un “Airbag” o un “Cinturón de Seguridad” para protegerlos ante un incidente.&nbsp;



Lo primero que pensé, al tomar este desafío, fue: ¡Agrego alguien de Seguridad en cada uno de los Squad’s y listo! ¡Con eso vamos a estar seguros! Pero como responsables, siempre, nos toca administrar recursos y los recursos, lamentablemente, no son infinitos. ¡Esto me llevo a preguntar! ¡A ver como estaba en otros lados! Por suerte, en Tecnología, compartir conocimiento es algo habitual y he podido nutrirme de experiencias ajenas. Me tope con 2 conceptos: Uno la cultura&nbsp;Spotify, con los Guilds, y por el otro con el&nbsp;Security Champion. Con ese approach comencé, en mi cabeza, a darle forma a lo que quería de Seguridad de la Información en este nuevo modelo.&nbsp;



En primer lugar, les adjunto la imagen, de como se organizan estos equipos:







Fíjense que el "Guild" esta formado por un integrante en cada Squad, de la Tribu, y transversalmente aparece la figura de Chapter Lead. Nuestra idea es la siguiente, cambiar el Chapter Lead por un Security Lead. Una figura con alto Seniority, en Seguridad de la Información. Alguien que tenga la visión holística de lo que pretendemos. En cada Squad, un Security Champion. Independientemente de que área sea, después veremos las formas de seleccionarlo. Esta en la forma en la que vamos hacer frente a muchos proyectos, con mas de un equipo, diferentes tecnologías y sobre todo una cultura “liviana” de Seguridad.



Seguramente te preguntas: ¿Qué es es un&nbsp;Security Champion? La respuesta es: Developers, QA’s, Arquitectos, Diseñadores, DevOps, ¡Cualquiera que este interesado, en Seguridad, dentro del Squad! Necesitamos alguien que este, como decimos, “En la Cocina” del proyecto. Que se convierta en el hombre de Seguridad, en el mismo. Pero lo mas importante, sin lugar a dudas, es que debe querer mejorar la Seguridad. ¿Que vamos a ganar, con esta figura? Escalar la seguridad a través de múltiples equipos, involucrar a personas que no son de seguridad, pero lo mas importante es vamos a&nbsp;generar una cultura de seguridad.



Según la encuesta del 2017 de&nbsp;OWASP Security Champion Survey,&nbsp;donde participaron profesionales de las distintas aristas, esto es lo que se espera de un Security Champion:







Podríamos sumarle, a vuelo de pájaro:



·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Asistir a conferencias de seguridad.



·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Definir las mejores practicas.



·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Priorizar historias relevantes, para seguridad, en el backlog.



·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Escribir pruebas de seguridad para riesgos identificados.



Tenemos que dar soluciones a preguntas que puede generarse el Squad. Imaginemos al equipo preguntándose ¿Cómo solucionamos este issue? ¡Ahí es donde el&nbsp;Security Champion generara valor!&nbsp;



Estos serian las principales "jugadas" del rol, su Playbook:







Identificar los Equipos



Preguntas como: ¿Un producto un equipo? ¿Qué tecnologías se usan? ¿Qué tenemos documentado? ¿Quién administra? ¿Revisiones actúales? ¿Calendario de lanzamiento? ¿Backlog? Debería quedarnos algo, similar, a esto:







Definir el Rol



Para tener un rol, claro, sera necesario que midamos el estado actual de seguridad entre los equipos. Deberemos definir qué metas se planean alcanzar a mediano plazo. Identificar en qué lugares el Security Champion podría ayudar. Que estos tengan sus roles y responsabilidades, definidos.



Dependiendo del progreso y la estrategia actual, las descripciones de los roles podrían ser:



Verificar revisiones de seguridad.Controlar las mejores prácticas dentro del equipo.Plantear problemas por riesgos en el código existente.Crear modelos de amenazas para nuevas características.Realizar escaneo automáticos para el código SAST &amp; DAST.Investigar informes de recompensas de errores.



Nominar el Security Champion



Es importante que se auto nomine, sin dudas. Tiene que salir de él, que se sienta atraído por esta nueva etapa y esta responsabilidad adquirida. Es crucial tener la aprobación en todos los niveles para evitar el argumento: ¡No tenemos tiempo para la Seguridad! ¿Lo conocen?



Una vez que el sombrero tiene dueño, tenemos que hacerlo sentir como lo que es Un Campeón de la Seguridad. Compartir las metas de Seguridad, hacerlo sentir parte, presentarlo con sus pares, darle su insignia de&nbsp;Security Champion 🏆🛡💪.



Canales de Comunicación



Opciones miles. ¿Slack? ¿Keybase? ¿IRC? ¿Skype?



Construir una Base de Conocimientos



Una Wiki interna como fuente. Opciones de KMS hay miles. ¡Solo es cuestión de Google It!



Ahí vamos a tener listados los Security Champions de los diferentes Squad’s, con los Roles y Procedimientos claramente definidos. Tendremos el apartado, a seguir, de SDLC con las mejores practicas. Listados de Riesgos, por que no un resumen BIA, y Vulnerabilidades asociadas. ¡Y los&nbsp;Check List! Ejemplos:&nbsp;



Lista de Verificación de Seguridad Web.Lista de Verificación de Seguridad Mobile.Lista de Verificación de Terceros.Lista de Verificación de Privacidad.Etc.



Algunos enlaces para tener en cuenta:



Security Knowledge FrameworkCERT Secure Coding



Mantener el Interes



Para los que amamos esto, lo más fácil. Veremos si para los entusiastas es igual. Acá algunas ideas, para armar el plan.



Workshops &amp; Trainings | Estrategia | Mejores Practicas.Miércoles de Hackeo.Mes de Bug's.Boletines mensuales de seguridad: Actualizaciones y Planes.Reconocimiento para Líderes.Otra fuente de comunicación. También sirven como puntos de control para todos.Conferencias.



¡Mantenerlos motivados!



Esto es un acercamiento de cómo abordamos los Squads, tener voz en cada Kick Off.



Para la próxima, entrada, les voy a compartir mi visión del Squad de Seguridad. El que brinda servicio a las Tribus, junto a Operaciones, Arquitectura, Etc. El conjunto que creara los Pipelines, con los controles de Seguridad, para que el CI/CD tenga en cada fase nuestros Check Point's que van desde Análisis de Código SAST &amp; DAST, Monitoreo, Plantillas de Infra as a Code, DevSecOps, Red Team &amp; Blue Team, Etc.



Muchas cosas nuevas, formas, problemas y soluciones. Espero que sirva, para copiar, para debatir, pero por sobre todo para mejorar.



Saludos,



Santi.



Referencias

