---
title: "Centralizando Secretos Dinámicos con Hashicorp Vault"
date: "2021-09-29 14:49:07"
slug: "Centralizando Secretos Dinámicos con Hashicorp Vault"
image: "Insert Image URL Here"
---


Hace un tiempo escribí sobre el manejo de secretos estáticos en HashiCorp Vault en esta entrada. ¡Hoy le tocan a los dinám24h-bottle lecosonnenschirm  gabsoutlet and-camicie andcamicienegozi  donkeywinkekatze  loevenichhut lamilanesaborse lecopavillon ynotoutlet lecopavillon capsvondutch ovyescarpe guardianialberto  diegodellapalma icos! Para ello vamos a usar un docker-compose donde levantareörhänge tatueringstudio  lego harry potter voldemort  porto moniz madeira live webcam  קמילוטרקט מסכה לשיער 250 מ"  cacciaviti elettricista professionali amazon  t shirt med tryk 40 år  camas mayor  shein vestidos coctel  t shirt med tryk 40 år  accessori moda menesello  conan exiles ps4  דאון טאון 300 משקל  haider maula mp3  اسباب وجع الجنب للحامل  oggetti per arredamento moderno amazon mos un Vault + MySQL Server. 



¿Que es Vault?



Como su nombre lo indica es una bóveda que nos sirve para la administración de secretos. Nos permite administrar el almacenamiento de los mismos como nombre de usuario, contraseña y credenciales de Base de Datos. 



Manos a la obra. Vamos a necesitar, para esta POC, tener instalado Docker &amp; Docker-Compose.



version: &quot;3.3&quot;
services:
  vault:
    image: vault
    container_name: vault-dev
    ports:
      - '8200:8200'
    restart: always
    volumes:
      - ./vault/config:/vault/config
      - ./vault/policies:/vault/policies
      - ./vault/data:/vault/data
      - ./vault/logs:/vault/logs
    environment:
      - 'VAULT_ADDR=http://localhost:8200'
      - 'VAULT_DEV_ROOT_TOKEN_ID=00000000-0000-0000-0000-000000000000'
      - 'dev'

    cap_add:
      - IPC_LOCK
  db:
    image: mysql/mysql-server:5.7
    container_name: mysql-dev
    restart: always
    environment:
     MYSQL_ROOT_PASSWORD: 's4nt1ag0'

    ports:
      - '3306:3306'
    expose:
      - '3306'
    volumes:
      - mysql-db:/var/lib/mysql
volumes:
  mysql-db:



Ahora corremos la configuración, del manifiesto, con docker-compose up.



docker-compose up



Configuración MySQL



Podríamos utilizar el usuario root, para la PoC, pero como "Best Practice" vamos a crear un usuario llamado wordpress con todos los privilegios necesarios para la prueba. ¡Vamos a conectarnos a nuestro docker, via shell, para crearlo! Si revisan el manifiesto lo llamamos container_name: mysql-dev. 



docker exec -it mysql-dev  mysql -uroot -p's4nt1ag0'
CREATE DATABASE 'wordpress_db';
CREATE USER 'wordpress'@'%' IDENTIFIED BY 'wordpress';
GRANT ALL PRIVILEGES ON *.* TO 'wordpress_db' WITH GRANT OPTION;



Configuración Vault



Vamos a conectarnos al docker, si revisan el manifiesto lo llamamos container_name: vault-dev. Ya en el contendor vamos agregar las variables de entorno e instalar el plugin the MySQL.



# Conexion al Contenedor, como root.
docker exec -it -u 0 vault-dev sh

# Configuracion de Variables de Entorno
export VAULT_TOKEN=00000000–0000–0000–0000–000000000000
export VAULT_ADDR=http://127.0.0.1:8200

# Habilitamos BBDD Generica
vault secrets enable database



Vault GUI



Ahora vamos a configurar la base de datos y los roles para el consumo. 



# Configurar Base de Datos para MySQL
vault write database/config/my-mysql-database \
    plugin_name=mysql-database-plugin \
    connection_url=&quot;wordpress:wordpress@tcp(mysql-dev:3306)/&quot; \
    allowed_roles=&quot;*&quot; \
    username=&quot;wordpress&quot; \
    password=&quot;wordpress&quot; \
    default_ttl=&quot;1h&quot; \
	max_ttl=&quot;386h&quot;

# Configurar Roles para Usuarios Dinamicos
vault write database/roles/my-role \
    db_name=wordpress_db \
    creation_statements=&quot;CREATE USER '{{name}}'@'%' IDENTIFIED BY '{{password}}';GRANT SELECT ON *.* TO '{{name}}'@'%';&quot; \
    default_ttl=&quot;1h&quot; \
    max_ttl=&quot;24h&quot;




¡Listo! Ahora podemos consumir Vault y obtener los secretos dinámicos con vault read database/creds/my-role. Aca les dejo una imagen como se popula la base de datos, con el usuarios &amp; password dinámico, y la forma de consumir los secretos.



vault read database/creds/my-role



select user from mysql.user;



En la primer imagen consultamos el rol y nos entrega el usuario &amp; password, mientras hacemos la query en la tabla de usuarios de MySQL encontramos el usuarios dinámico que tiene un lease de 1 hora. 



Aca le dejo el comando curl para poder jugar con el JSON.



curl --header &quot;X-Vault-Token: $VAULT_TOKEN&quot; \
       --request GET \
       http://127.0.0.1:8200/v1/database/creds/my-role | jq



curl



¡Espero que les sirva!

