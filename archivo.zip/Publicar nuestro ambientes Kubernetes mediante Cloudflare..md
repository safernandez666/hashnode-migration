---
title: "Publicar nuestro ambientes Kubernetes mediante Cloudflare."
date: "2024-01-28 17:08:30"
slug: "Publicar nuestro ambientes Kubernetes mediante Cloudflare."
image: "Insert Image URL Here"
---


Muchas veces empezamos a jugar con nuestro cluster en nuestro equipo y llegamos a la necesidad, tal vez por gusto o ganas de mostrar nuestros conocimientos al mundo, de querer exponerlos. Una buena manera de hacerlo puede ser a traves de Cloudflare. Con Cloudflare Tunnel se puede conectar el origen a Cloudflare y proporcionar servicio sin exponer ningún puerto en el servidor o clúster, minimizando así la superficie de ataque.







Para esta prueba vamos a tener que tener un dominio, configurado en Cloudflare. Vamos a ir a nuestro dominio, asociado, Access y luego lanzamos nuestra Zona de Confianza 0. 







Ahora vamos a comentar con el deployment, en nuestro cluster de cloudfalred, que sera quien dialoge y genere los registros en la CDN. Les dejo el manifiesto, para poder aplicarlo en nuestro ambiente.



apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: cloudflared
  name: cloudflared
spec:
  selector:
    matchLabels:
      app: cloudflared
  template:
    metadata:
      labels:
        app: cloudflared
    spec:
      containers:
      - name: cloudflared
        image: cloudflare/cloudflared:2022.7.1
        # image: ghcr.io/maggie0002/cloudflared:2022.7.1
        imagePullPolicy: Always
        args: [&quot;tunnel&quot;, &quot;--no-autoupdate&quot;, &quot;run&quot;, &quot;--token=TOKEN&quot;]
      restartPolicy: Always
      terminationGracePeriodSeconds: 60
      



Vamos a necesitar el Token, para acceder a Clouflare. Para ello vamos a dar siguiente y seleccionar el despliegue de con Docker. Sustraemos el token y lo cambiamos en nuestro manifiesto. Con eso estamos listos para desplegar. Es importante entender que almacenar el token en el archivo yaml no es seguro. Para garantizar la seguridad puede almacenar el token en Kubernetes Secrets y utilizarlo a través de la variable de entorno. Hay varias formas mas, pero para fines practicos vamos a seguir asi. 











Aplicamos los el manifiesto de clouflared. Una vez aplicado, damos continuar para configurar nuestro registro. Pero antes vamos a desplegar nuestra aplicacion. En mi caso usare una imagen de microbot. Aca les dejo el deployment y el servicio, todo en uno. 



apiVersion: apps/v1
kind: Deployment
metadata:
  name: microbot
spec:
  selector:
    matchLabels:
      app: microbot
  template:
    metadata:
      labels:
        app: microbot
    spec:
      containers:
      - name: microbot
        image: cdkbot/microbot-amd64
        imagePullPolicy: Always
        ports:
        - containerPort: 80
      restartPolicy: Always
      terminationGracePeriodSeconds: 60
---
apiVersion: v1
kind: Service
metadata:
  name: microbot-svc
spec:
  type: ClusterIP
  ports:
    - targetPort: 80
      port: 80
  selector:
      app: microbot



Revisamos donde esta atendiendo el servicio, para configurar el tunel. En nuestro caso es microbot-svc:80.











Salvamos! Vamos a revisar nuestros tuneles.







Ahora revisamos y UALA! Nuestro deployment, local, publicado a internet via Cloudflare. Revisen en nuestra imagen el id del container, para chequear el funcionamiento. 







Espero que les sirva, es una manera rapida y segura de tener nuestro ambiente de manera publica. 

