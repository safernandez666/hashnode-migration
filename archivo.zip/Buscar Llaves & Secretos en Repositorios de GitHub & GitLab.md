---
title: "Buscar Llaves & Secretos en Repositorios de GitHub & GitLab"
date: "2020-05-26 19:29:16"
slug: "Buscar Llaves & Secretos en Repositorios de GitHub & GitLab"
image: "Insert Image URL Here"
---


Introducción



Uno de losmandarinaduckoutlet fracominasaldi and-camicie harmonte-blaine marellasaldi corinne abbigliamento sexy benettonoutlet saldibenetton moorecains ovyeshop gabsoutlet diego-dalla-palma gabsoutlet lamilanesaborse 24hbottle grandes problemas que tenemos en nuestras compañías es que los Dev's guardan contraseñas no encriptadas, secretos y cualquier tipo de datos no deseados en los repositorios GitHub y GitLab. Gitleaks te da una forma de escanear tתנור בילד אין אייס מוצרי חשמל  zasto su mini suknje seksi  porto moniz madeira live webcam  kärring moppe  tutto echarpes feulles enfant  can you connect usb microphone to soubd card  puma basket trim block  jimmy hex tricouri  bioscalin nutricolor prezzo  zasto su mini suknje seksi  חנות צילום ופיתוח תמונות באזריאלי  nike tennis herren  haider maula mp3  accessori moda menesello  vesta kožešinová us repositorios de Git en busca de estos datos no deseados que deberían ser privados. Los escaneos pueden ser automatizados para que encajen perfectamente en el flujo de trabajo de CI/CD para la identificación de secretos antes de que se profundice en la base de código.



Características Gitleaks




Escaneo para commited Secrets.



Escaneo para uncommited Secrets, parte del Shift to the Left.



Despinible&nbsp;Github Action



Gitlab &amp; Github Soporte API.



Reglas de Configuracion Basadas en TOML &amp; Regex.



Alta performance basada en&nbsp;go-git.



JSON &amp; CSV Output.



Escaneo de Repositorios Privados.




Instalación



Descargamos el release para nuestro Sistema Operativo. En mi caso lo voy a realizar sobre Ubuntu, donde tengo Jenkins. Aca el link.



cd /tmp
wget https://github.com/zricethezav/gitleaks/releases/download/v4.2.0/gitleaks-linux-amd64	 
sudo chmod +x gitleaks
sudo mv gitleaks /usr/local/bin/



Vamos a correrlo sobre dos repositorios publicos. Uno con Leaks y otro sin.



Leaks



Gitleaks proporciona códigos de salida consistentes para ayudar a automatizar los flujos de trabajo, como las plataformas CI/CD y el escaneo en masa.



0: no leaks
1: leaks present
2: error encountered



Vamos a colgarlo de nuestro Pipeline de Jenkins. Aqui mi Clone a GitHub.



GitHub Clone Jenkins



Agregamos un paso apenas salimos de la clonacion. El análisis podemos hacerlo local o contra el repositorio. Para que quede, mejor, graficado lo hare contra el repositorio.



Linea de Comando



Donde dice 0, cambiamos por 1. Si la salida es 1, de GitLeaks, abortar el CI. ¡Vamos a ver que pasa!



Jenkins Job Failure



Como ven nuestro CI fallo, debido a la salida = 1. Haciendo que el Pipeline no continue.  



¡Espero que les sirva! Es algo rapido que nos ayuda a que nuestros Dev's &amp; DevOps no compartan, sin querer, las llaves del Reino.



Algo muy interesante es agregar pre-commit-hook agregando lo siguiente en esta ruta del repositorio&nbsp;&lt;repo&gt;/.git/hooks/pre-commit:



#!/bin/sh
# This is an example of what adding gitleaks to a pre-commit hook would look like.

gitleaksEnabled=$(git config --bool hooks.gitleaks)
cmd=&quot;gitleaks --verbose --redact --pretty&quot;
if [ $gitleaksEnabled == &quot;true&quot; ]; then
    $cmd
    if [ $? -eq 1 ]; then
cat &lt;&lt;\EOF
Error: gitleaks has detected sensitive information in your changes.
If you know what you are doing you can disable this check using:
    git config hooks.gitleaks false
EOF
exit 1
    fi
fi



Ahora antes de realizar un Commit, se revisara. 



¡Espero les sirva y puedan sacarle provecho!



Referencias



https://github.com/zricethezav/gitleaks



https://githooks.com/

