---
title: "Pasando de DevOps a DevSecOps en nuestro CI/CD con GitHub Actions y Okteto."
date: "2020-12-22 12:55:16"
slug: "Pasando de DevOps a DevSecOps en nuestro CI-CD con GitHub Actions y Okteto."
image: "Insert Image URL Here"
---


Esta es la segunda parte de la entrada de CI/CD, gratis, con GitHub Ackleankanteenkinder  diegodallapalmaoutlet  completini  intimi molto sexy saldibenetton harmontblainescarpe  gioie-di-gea lamilanesaborse donkeywinkekatze  negozigeox 24h-bottle vondutchmutzen corinne  abbigliamento sexy akuscarpe ovyeshop gabsoutlet tions &amp; Okteto como cluster de Kubernetes.



¡Ya tenemos nuestro Pipeline funcionando! Ahora vamos a transformarnos en DevSecOps y vamos a integrar un poco de Seguridad, que nunca viene mal, a nuestro CI/CD.



Me puse a revisar y creo que si pensamos en Analisis de Codigo, pensamoshawaiian prodotti solari&nbsp; kinderwagen peg perego pliko p3&nbsp; logitech dongle&nbsp; ציפוי מגנטי לדלתות&nbsp; разклонител пвц ппк ф40 ф40-87градуса&nbsp; oliver dragojevic majica&nbsp; dulap exterior dedeman&nbsp; przez te dresy zielone&nbsp; come pulire una caffettiera di alluminio&nbsp; כרית פריד קלאסיק&nbsp; sklopka za mješalicu betona&nbsp; prevent jacke&nbsp; dita logo משקפי שמש&nbsp; חזן צוקרמן שמלות כלה מחירים&nbsp; liu jo muske majice&nbsp; en SAST &amp; DAST. Entiendo que es un buen comienzo, pero ¡Vamos a revisar un poco mas! Vamos agregar funcionalidades como:



· SAST con SonarCloud· Detect Secrets· Análisis de Imagen Docker con Trivy de AquaSec· DAST con OWASP ZAP



SAST con SonarCloud



Como muchos saben SonarQube es una plataforma para la calidad del codigo. Usa diversas herramientas de análisis estático de código fuente o SAST como Checkstyle, PMD o FindBugs para obtener métricas que pueden ayudar a mejorar la calidad del código de un programa.



Vamos a usar la version SaaS SonarCloud, que para proyectos publicos es gratis. Para poder agregarlo a nuestro GitHub Actions es necesita interactuar con el servicio, para ello vamos a gestionar el Token, requerido. 



Primero creamos el proyecto en SonarCloud.



Nuevo Proyecto



Vamos a picar el el logo de GitHub Actions y seguimos los pasos.



GitHub Actions



Seguimos con los pasos. Copiamos el Token, que luego lo utilizaremos en GitHub.



GitHub Secrets



Este es el YAML para crear el "Actions" que formara parate del Workflow.



YAML



Sera necesario crear el archivo de propiedades.



SonarCloud Properties



Luego de haber realizado el push, podremos revisar la calidad del codigo y las sugerencias de seguridad que arrojo en Analisis SAST en sonarcloud.io.



En la documentacion del GitHub Actions se pueden encontrar como manejar los umbrales para recharzar el deploy, en base a lo que configuremos. 



SonarCloud



Cargamos el Token, que habiamos copiado.



Token SONAR_TOKEN



Detect Secrets



Vamos agregar este codigo a nuestro YAML. Estan son algunas de las cosas que estara revisando:



· AWSKeyDetector· ArtifactoryDetector· Base64HighEntropyString· BasicAuthDetector· HexHighEntropyString· JwtTokenDetector· KeywordDetector· MailchimpDetector· PrivateKeyDetector· SlackDetector· SoftlayerDetector· StripeDetector



    ##########################
    #     Detect Secrets     #
    ##########################
    - name: Detect Secrets
      uses: evanextreme/detect-secrets-action@1.0.0



Esta es una buena manera de revisar si se filtra algún acceso. 



Análisis de Imagen Docker 



Muy importante, revisar nuestras imagen de Docker. Para ello utilizaremos Trivy de AquaSec. ¡Vamos agregar el código al YAML!



    ##########################
    #       Trivy Scan       #
    ##########################
    - name: Run Trivy vulnerability scanner
      uses: aquasecurity/trivy-action@master
      with:
        image-ref: 'docker.io/safernandez666/okteto:${{ github.sha }}'
        format: 'template'
        template: '@/contrib/sarif.tpl'
        output: 'trivy-results.sarif'

    - name: Upload Trivy scan results to GitHub Security tab
      uses: github/codeql-action/upload-sarif@v1
      with:
        sarif_file: 'trivy-results.sarif'



Si miran el segundo Step la salida se sube al Tab de GitHub. Es ahi donde revisaremos los resultados. 



Trivy Scanning



DAST con OWASP ZAP Scan



Vamos agregar el Análisis DAST. Es importante apuntar al EndPoint del Deployment. En nuestro caso el Kubernetes en Okteto.



    ##########################
    #      DAST Analisys     #
    ##########################
    - name: ZAP Scan
      uses: zaproxy/action-baseline@v0.4.0
      with:
        target: 'https://flaskapp-deployment-safernandez666.cloud.okteto.net/'



Los resultados, segun las configuraciones que hagamos, van a salir en la salida del Push o tambien via Email si hemos configurado el Dependanbot Alert. 



Salida



Email



Creo que estos cuatro controles nos dan un baseline de seguridad apropiado. Podemos agregar Linter o revisar los YAML's de los manifiestos de Kubernetes. Deberán ustedes generar los umbrales para truncar o no el despliegue.



¡Espero les sirva!



Les dejo el link del proyecto.

