---
title: "Visualizando los Log's de Kong, nuestro API Manager, en Graylog."
date: "2019-03-21 22:33:51"
slug: "Visualizando los Log's de Kong, nuestro API Manager, en Graylog."
image: "Insert Image URL Here"
---


Hace unos días aprendimos a crear una API, con Python y Flask, e implementamos un API Manager, con Kong, para manejar la seguridad de nuestro servicio.



Vamos a enviar los log's de Kong a nuestro servidor Graylog, que instalamos  en otra entrada, 



 Instalación de Plugin Syslog en Kong 



Vamos al Dashboard, de Kong, e instalamos el Plugin. Para los fines prácticos, vamos a logear todo. Pero podríamos agregar granularidad, seleccionado la ruta, el servicio o el usuario de consumo.



Agregamos Plugin



Manejo del Status del Plugin



Ya tenemos, listo el logeo. Ahora vamos a modificar el rsyslog, para direccionarlo a nuestro servidor Graylog. En este caso, como en el de las entradas anteriores, el mismo tiene la dirección 10.0.2.20. Voy a editar la Regla por defecto, en la ruta /etc/rsyslog/50-default.conf, agregando:



*.* @10.0.2.20:5014;RSYSLOG_SyslogProtocol23Format



Vamos a enviar a Graylog, en el puerto 5014. Es importante el puerto para la creación del INPUT. 



rsyslog



Reiniciamos el rsyslog, para que tome los cambios. 



Reinicio de Rsyslog



Creación del Input en Graylog



Creamos el input en System/Inputs &gt; Syslog UDP. Recordemos, que debemos escuchar en el puerto 5014.



 Input Syslog UDP en el Puerto 5014



Si seleccionamos Show received messages:



Filtramos los Logs de Kong



Vamos al Input, para poder realizar un Extrator. El campo message, del log, tiene un JSON con toda la información que necesitamos. El extractar, va a segmentar el JSON. Acomodando las Key's con sus valores, de una manera que Graylog, pueda trabajar con ellos. Una manera de normalizarlo.



Ejecutamos alguna consulta, para generar trafico.



GET Status 200



Revisamos el log y vemos el JSON, dentro del campo message.



Campo Message



Vamos agregar el Extractor.



Creación del Extractor



Configuramos y probamos! Si vemos el JSON, como corresponde, guardamos el extractor.



Extractor



JSON del Message



Ahora podemos hacer el filtro, por cada campo. Podemos crear un Dashboard, en mi caso cree Kong API Manager que luego les compartire, para enviar las gráficas de datos que me interesan, ejemplo: los códigos de respuesta.



responses_status



Picamos en Quick Values arriba se creara una gráfica donde podemos ver los códigos de respuesta! Esa gráfica, la agregamos a nuestro Dashboard. 



Gráfico de Torta de responses_status



Les muestro el mio. 



Dashboard Kong



Las opciones son infinitas. En el que les comparto podemos ver:



Metodos UtilizadosRutas ConsultadasRespuestas de EstadoUsuarios 



De esta manera tenemos un Snapshot para ver que esta pasando con nuestra API, en tiempo real.



Espero les guste! 





