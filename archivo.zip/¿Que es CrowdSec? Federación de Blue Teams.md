---
title: "¿Que es CrowdSec? Federación de Blue Teams"
date: "2023-01-15 22:06:44"
slug: "¿Que es CrowdSec? Federación de Blue Teams"
image: "Insert Image URL Here"
---


Los que estamos en esto hace tiempo, siempre escuchamos que la Seguridad es una cebolla y la suma de las capas nos otorgará una mejor defensa en profundidad. CrowdSec llega para agregar una nueva capa de Seguridad, a nuestro servicios, con esté nuevo concepto de “Federating Blue Teams”. Lo que plantea está herramientas de código abierto es contribuir a elaborar una lista de bloqueo en tiempo real, añadiendo y eliminado direcciones IP que los delincuentes utilizan y abandonan. Nutrirse de esas listas.



Para los vieja escuela deberían de verlo con un fail2ban, colaborativo y mejorado. Consume muy pocos recursos, es multi plataforma, mutualización de direcciones IP con una base de datos compartida entre todos los usuarios de Crowndsec pero sobre todo es fácil de usar.&nbsp;



El proyecto posee un Marketplace donde se pueden descargar reglas para asegurar sus servidores, Nginx, Apache, Docker, Traefik, etc.!



Les paso a mostrar, antes de ir la prueba, la arquitectura. Es muy sencillo el concepto donde a través de nuestras experiencias generamos evidencias de los ataques recibidos y enviamos los reportes a la comunidad, la misma que nos nutre para tomar nuestras decisiones.



CrowdSec



Instalación de CrowdSec



Este paso es tan sencillo como cualquier otra instalación, primero los repositorios.



curl -s https://packagecloud.io/install/repositories/crowdsec/crowdsec/script.deb.sh | sudo bash



Hacemos el update.



sudo apt-get update



Instalamos CrowdSec.



sudo apt-get install crowdsec



El proceso de instalación donde podemos ver el descubrimiento y la instalación y configuración automática para sshd y linux. Ya tenemos CrowdSec listo para usar, en instalación local. Si ya hubiésemos tenido Apache2 instalado, hubiese bajado la colección correspondiente. Como no estaba, lo instalaremos posteriormente, mas adelante les muestro como hacerlo.



Instalación



Antes de comenzar a configurar e instalar un bouncer, podemos jugar con el cscli client que sera de ayuda para reglas, métricas, listas y todo lo necesario.



cscli



Voy agregar la coleccion para Apache2, en nuestro Web Server. Vamos a ver la consola de métricas. Como podemos ver en la captura, podemos ver los ficheros fuente utilizados y sus estadísticas y también los diferentes parsers utilizados que permiten detectar.



Metrics



Les dejo una lista de comandos, que les serviran para la PoC.




cscli alerts list | Listado de Alertas.



cscli alerts inspect ID | Detalle de la Alerta, que deseamos investigar.



cscli decisions list | Lista de los "bans" o bloqueados.



cscli parsers list | Listado de parseadores, que no es ni mas ni menos lo que nos habilita a leer e interpretar logs.



cscli scenarios list | Los escenarios son las configuraciones que detectarán los comportamientos y las acciones a realizar.



cscli postoverflows list | Lista de los servicios en "Whitelist" que exceptúan el bloqueo. 




Instalación de Bouncer



Los bouncers son quienes nos habilitaran a bloquear ataques. Les dejo el enlace para que revisen colecciones, configuraciones y bouncers. En esta PoC vamos a instalar cs-firewall-bouncer y ya que estamos la colección de Apache2 con cscli, asi tiene algunas opciones.



sudo apt install crowdsec-firewall-bouncer-iptables



Podemos ver la configuración en la siguiente ruta.



sudo cat /etc/crowdsec/bouncers/crowdsec-firewall-bouncer.yaml



Instalamos la colección de Apache2 y le decimos donde debería levantar los logs.



sudo cscli collections install crowdsecurity/apache2

cat &lt;&lt; EOF | sudo tee -a /etc/crowdsec/acquis.yaml
filenames:
  - /var/log/apache2/*.log
labels:
  type: apache2
---
EOF



Vamos a ver las métricas para confirmar que hemos agregado la fuente de logs de apache2, algo que antes no estaba sumado. 



cscli metrics



Como he instalado Crowdsec en un servidor Web, vamos a instalar la lista blanca para los "crawlers".



En la página de configuración CrowdSec Hub encontramos la línea a ejecutar.



sudo cscli postoverflows install crowdsecurity/seo-bots-whitelist



Ahora restart!



sudo systemctl reload crowdsec



Antes de dejar esta sección voy a revisar que tenemos colecciones tenemos habilitadas con cscli hub list, ya estamos listos para estos diferentes ataques. 



cscli hub list



Vamos a parar la pelota, hasta ahora tenemos CrowdSec sobre un Web Server, que tenia Apache2, y estamos protegidos de ataques de Fuerza Bruta sobre SSH y Web. En los próximos pasos emulamos un ataque, para ver como se comporta CrowdSec, en su hardening, y enviaremos los logs a unos tableros para tener visibilidad.



Ataque de Fuerza Bruta



Para esta parte voy a utilizar un Ubuntu, como atacante, y vamos a hacernos de un repositorio de GitHub que tiene una herramienta para este menester. Si estas leyendo esto seguramente sabes clonar un repositorio, si no Google It! 😎



Primero revisamos nuestro lista de alarmas o decisiones, como verán esta vacía.



cscli decision list



Ahora desde la consola del atacante, vamos a lanzar SSHBrute.py con el comando:



python3 ssh-brute.py -ip 192.168.1.12 -p 22



Ataque



Van a notar que automaticamente nuestro servidor deja de responder, por que CrowdSec hizo su magia. Revisamos la lista de decisiones.



Lista de decisiones



Vamos a probar, como trabaja con el Bouncer de Apache2. Primero tengo que eliminar ese banneo, para darle la chance al atacante 😄. Vamos a probar lo aprendido e intentar activar el escenario crowdsecurity/http-sensitive-files accediendo a ficheros sensibles. Este escenario se activa tras 4 intentos de acceder a ficheros sensibles en menos de 5 segundos. Vamos a instalarlo y luego configurar el ataque.



sudo cscli scenarios install crowdsecurity/http-sensitive-files



Del lado de atacante hacemos algunas búsquedas, con curl.



URL="http://DIRECCIONDEWEBSERVER"

curl "$URL"/.git
curl "$URL"/.htaccess
curl "$URL"/.bashrc
curl "$URL"/.bash_history
curl "$URL"/.ssh



Uala! Ahora vemos que se banneo la ip del atacante, nuevamente, pero por otro escenario.



Decision list, por directorios sencibles



Esto es todo por ahora. Esto se puede visualizar, de una mejor manera en crowdsec.net, solo debemos enrolar nuestros servidores. Ahi veremos el banneo por el ataque SSH y el scanneo de directorios sensibles.



Dashboard app.crowdsec.net



Creo que para cerrar seria interesante realizar una conexión a un canal de Telegram o Slack, esa parte la pueden ver aqui.  Espero que les haya gustado. Creo que este IPs, tiene mucho potencial a la hora de hardenizar nuestros servicios.



Bonus Track



Desiciones Manuales



Lógicamente tenemos la posibilidad de hacer elecciones, manuales, de cada regla. Les voy a dejar algunas que pueden hacerle la vida más sencilla.



Banneo de IP por 4 horas.



sudo cscli decisions add --ip XXX.XXX.XXX.XXX



Banneo de IP por 24 horas.



sudo cscli decisions add --ip XXX.XXX.XXX.XXX --duration 24h



Banneo de rango.



sudo cscli decesions add --range XXX.XXX.XXX.XXX/16



Eliminar banneos de IP o rango.



sudo cscli decisions delete --ip XXX.XXX.XXX.XXX
sudo cscli decesions delete --range XXX.XXX.XXX.XXX/16

