---
title: "Análisis de Dependencias con Dependency Check"
date: "2019-12-29 00:46:35"
slug: "Análisis de Dependencias con Dependency Check"
image: "Insert Image URL Here"
---


Análisis de Dependencias con Dependency Check. Las aplicaciones mod24bottlesclima akuscarpe ovyescarpe fracominaabiti scarpeovye loevenichmutze loevenichhutkaufen  gabsoutlet uspoloassnscarpe  pasante  kondom guardianialberto  andcamiciesaldi  corinne  abbigliamento sexy blundstoneprezzi  gabsoutlet ernas aprovechan la disponibilidad de los componentes existentes para su uso como bloques de construcción en el desarrollo de aplicaciones. Al utilizar los componentes existentes, las organizaciones pueden reducir drásticamente sus tiempos. Sin embargo, la re utilización de los componentes existentes tiene un costo. Las organizaciones que construyen sobre los componentes existentes asumen el riesgo por el software que no crearon. Las vulnerabilidades de los componentes de terceros son heredadas por todas las aplicaciones que utilizan esos componentes. Los Top Ten deразклонител пвц ппк ф40 ф40-87градуса  wildleder portemonnaie damen  come pulire una caffettiera di alluminio  tablo soba  guarnitura kcnc mtb  motoros sisak àrg  rte carta  logitech dongle  אופניים עם מנוע עזר חשמלי  modern love مترجم الحلقة 2  adidas t shirt 1972  pianta viola pendente  נחד משקפיים  kinderwagen peg perego pliko p3  amarillo pastel pantone  OWASP (2013 y 2017) reconocen el riesgo de usar componentes con vulnerabilidades conocidas.



Dependency-Check permite que sus equipos de DevOps aceleren mientras siguen controlando el uso de los componentes y cualquier riesgo heredado.



Vamos a instalar Dependency-Check Cli. Vamos a descargar y moverlo la carpeta /opt de nuestra instalación de Jenkins.



wget https://dl.bintray.com/jeremy-long/owasp/dependency-check-5.2.4-release.zip
sudo unzip dependency-check-5.2.4-release.zip
sudo mv dependency-check /opt/
sudo chown -R $USER /opt/dependency-check



Instalamos el PlugIn en Jenkins y configuramos la ruta.







Reiniciamos.







Configuramos la ruta, correspondiente en Global Configuration Tool.







Vamos a configurar el Job, que hicimos en los tutoriales anteriores, para revisar las dependencias que importa el Python.







En la documentación podemos ver muchos Flags para configurar. En nuestro caso vamos a ir con algo sencillo. ¡Lo ejecutamos! No solo hemos revisado la calidad del Software, con SonarQube, si no que ahora tendremos el informe de las dependencias utilizadas.







En el Flag --out ubicamos el informe en la carpeta del proyecto, pero podríamos enviarlo por mail, realizar tareas, etc. 











¡Vamos a picar, la version HTML, para darle una mirada!







Ya tenemos forma de saber si nuestras dependencias tienen Bugs. Listo para hacer un Análisis de Dependencias con Dependency Check. Les recomiendo que le peguen una mirada a Dependency-Track una version Web para hacer el seguimiento.



Esto es parte de mejorar nuestro Pipeline, nuestra Seguridad y sobre todo nuestros sistemas. Podría resultar interesante el formato JSON, de reporte, para poder generar Tickets, por ejemplo, en JIRA.



¡Espero que les sirva!



No dejen de revisar los artículos, anteriores, de Análisis SAST con SonarQube y Jenkins.

