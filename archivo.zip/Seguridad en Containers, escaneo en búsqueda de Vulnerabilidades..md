---
title: "Seguridad en Containers, escaneo en búsqueda de Vulnerabilidades."
date: "2020-05-23 23:45:50"
slug: "Seguridad en Containers, escaneo en búsqueda de Vulnerabilidades."
image: "Insert Image URL Here"
---


En esta entrada vsaldigeox blaineharmont marellaoutlet saldigeox ovyescarpe akutrekkingshop harmontblainescarpe donkeyluckycat 24bottles ynotsaldi vondutchmutzen benettonoutlet tatacalzature moorecains ynotsaldiamos a ver como podemos realizar un escaneado de nuestros contenedores con Trivy de AquaSec.



Trivy es una herramienta Open Source para escanear imágenes de contenedores en busca de vulnerabilidades en los paquetes del sistema operativo y las dependencias de las aplicaciones.Vamadidas  superstar bot metalic&nbsp; s85956  adidas&nbsp; basket  veja argenté&nbsp; modifica per  giochi 3ds&nbsp; червило  в ръчен багаж&nbsp; plantronics  airpods&nbsp; رسم  فنجان قهوة سهل&nbsp; תנור  בילד אין אייס מוצרי חשמל&nbsp; דיו  למדפסת בזול&nbsp; marine  stickers for boat&nbsp; obelink tipi  tent&nbsp; suport  telefon auto allview&nbsp; tapijt  kleden&nbsp; frozen  schminktisch toys r us&nbsp; детски  фолклорни музикални инструменти&nbsp; os a cubrir características, uso y otras opciones disponibles. Lo mejor de todo que podemos agregarlo a nuestra CI, lo cual lo hace mas poderosa.



Instalación



En mi caso voy hacerlo en Ubuntu agregando la fuente.



sudo apt-get install wget apt-transport-https gnupg lsb-release
wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | sudo apt-key add -
echo deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main | sudo tee -a /etc/apt/sources.list.d/trivy.list
sudo apt-get update
sudo apt-get install trivy



Trivy no es la unica opción que tenemos para esta tarea, podemos usar Clair o Anchore.



Vamos a trabajar, para esta prueba, en una imagen de mi DockerHub.



Docker Hub



Vamos a bajar la imagen.



docker pull



Uso



Hora de correr Trivy.



trivy safernandez666/cicd_num5




Seleccione una imagen añeja, adrede, para que nos evidencie problemas.



Output



Como ven esta imagen esta en un estado calamitoso. Podríamos ver el código de salida, para poder jugar con el. Se puede forzar con --exit-code=1 para poder saber si pasa o no. 



Con este comando, podemos ver la salida.



echo $?



Voy a probarlo una imagen de alpine, vieja, y otra nueva que no debería tener vulnerabilidades.



Imagen alpine:3.9.2



Código de salida igual a 1, por ende tiene vulnerabilidades.







 Código de salida igual a 0, por ende no tiene vulnerabilidades.



Trivy soporta gran cantidad de Sistemas Operativos y dependencias, soporta gran cantidad de formatos de imagenes, .tar o OCI, y se puede agregar a diferentes CI's como Travis CI, CircleCI, Jenkins, etc.



Podemos, tambien, tener salidas en JSON o Template y filtrar por Severidad o Tipo.



Cuando Trivy comienza a escanear la imagen siempre actualiza la base de datos para tener la última información almacenada y generalmente es rápido. Pero esto se puede saltar usando la opción -skip-update. Es posible ignorar las vulnerabilidades que no pueden ser solucionadas usando la opción --ignore-unfixed.



Hagamos la prueba activando la salida y filtrando las Vulnerabilidades CRITICAS y HIGH.



Salida 1 con Filtros



Aca les dejo la documentación para agregar Trivy a los Pipeline.



Espero que les sirva para mejorar su infraestructura. ¡No solo de SAST &amp; DAST vive el DevSecOps!



Referencias



Container Security



Tweaking Trivy output to fit your workflow



Trivy - container image scanning

