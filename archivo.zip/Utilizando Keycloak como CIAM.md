---
title: "Utilizando Keycloak como CIAM"
date: ""
slug: "Utilizando Keycloak como CIAM"
image: "Insert Image URL Here"
---


Keycloak es un producto de código abierto que permite inicio inicio de sesión con Identity Managment y Access Management para aplicaciones y servicios modernos. Escrito en Java es compatible con protocolos de federación de identidad SAML v2 y OpenID Connect / OAuth2. 



La finalidad del mismo es facilitar la protección de aplicaciones y servicios con muy poca, o ninguna, codificación. Una buena manera de "quitarnos de encima" lo concerniente a autenticación y autorización. 



Dentro de sus principales características:



inicio de sesión únicoSoporte para protocolos estándarCuenta aplicaciones seguras y servicio simplificadoLDAP compatible como repositorio de usuarios externodelegación de autenticación (inicio de sesión social)alto rendimiento: clúster de servidores, escalable, alta disponibilidadtotalmente compatible con la contenerizacion.temas simples para implementarautenticación fuerte por código nativo de un solo uso (OTP) a través de FreeOTP o Google Authenticatorauto-solución de problemas si olvida su contraseñaauto-creación de cuentas (por forma o las llamadas autenticaciones sociales)extensible: base de usuarios, métodos de autenticación, protocolos.



Para esta PoC vamos a usar Keycloak con MySQL en un docker-compose.



version: '3'

volumes:
  mysql_data:
      driver: local

services:
  mysql:
      image: mysql:5.7
      volumes:
        - mysql_data:/var/lib/mysql
      environment:
        MYSQL_ROOT_PASSWORD: root
        MYSQL_DATABASE: keycloak
        MYSQL_USER: keycloak
        MYSQL_PASSWORD: password
  keycloak:
      image: quay.io/keycloak/keycloak:legacy
      environment:
        DB_VENDOR: MYSQL
        DB_ADDR: mysql
        DB_DATABASE: keycloak
        DB_USER: keycloak
        DB_PASSWORD: password
        KEYCLOAK_USER: admin
        KEYCLOAK_PASSWORD: admin
        #Uncomment the line below if you want to specify JDBC parameters. The parameter below is just an example, and it shouldn't be used in production without knowledge. It is highly recommended that you read the MySQL JDBC driver documentation in order to use it.
        #JDBC_PARAMS: &quot;connectTimeout=30000&quot;
      ports:
        - 8080:8080
      depends_on:
        - mysql



Una vez que tenemos arriba los contenedores con docker-compose up, vamos ir a la web e iniciamos sesión con user: admin &amp; pass: admin.





