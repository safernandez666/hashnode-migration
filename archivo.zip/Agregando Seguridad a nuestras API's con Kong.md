---
title: "Agregando Seguridad a nuestras API's con Kong"
date: "2019-03-09 21:24:01"
slug: "Agregando Seguridad a nuestras API's con Kong"
image: "Insert Image URL Here"
---


En la primera parte, aprendimos a generar nuestra propia API con Python, Flask contra MySQL. Llego el momento, de darles seguridad. Para ello utilizaremos Kong, un  API  Gateway Open Source. Estos nos proporcionan seguridad y control sobre el acceso al sentarse frente a cualquier número de servicios API. 



KONG, Tyk, API Umbrella, Ambassador, Gravitee.io, etc., son algunas de los  API Gateway actualmente disponibles, en el mercado. Nos proporcionaran servicios como autenticación, autorizacion, api keys, análisis, registro, transformación, etc., a nuestros Endpoints.



Pasaremos de una arquitectura, simple y desprotegida, a otra con un Manager, dándonos la posibilidad de escalar en nuestro Backend de una manera flexible. 







Instalación de Kong 



Vamos a comenzar con la instalación de Kong. En esta prueba de concepto, mi arquitectura es la siguiente:  



Servidor KONGServidor API192.168.0.139192.168.0.138kong.ironbox.localapi.ironbox.local



Podríamos tener la cantidad que deseáramos de servicios API. Ahí estaría Kong, para gestionar esos Endpoints.



Para instalar Kong descargamos el paquete e instalamos Postgresql. Crearemos el usuario, para que Kong se conecte a la Base de Datos y lo ejecutaremos. 



Instalación de Kong y Postgresql



Creación de Servicios y Reglas



Una vez que tenemos el API Manager, en linea, vamos a poder crear los Servicios y las Rutas, para el manejo de los Match's.



El manejo de Kong, se realiza por API, así que agregamos mediante POST el servicio API_Usuarios y una regla que maneje el verbo GET. 



Servicios y Rutas



Listo! Ya tenemos el Servicio Publicado. ¿Vamos a probarlo?



cURL



Consulta, mediante Postman



¡Perfecto! ¡Consultamos a la dirección, publica, con el Path /user y recibimos el JSON que esperábamos!



Instalación de Dashboard



Vamos a instalar un Dashboard, hay miles, para hacernos la vida mas fácil.



Instalación de Dashboard



Iniciando el Dashboard



¡Listo! ¡Tenemos una interfaz GUI para la gestión! Ahora podemos agregar, de una manera mas sencilla, Plugins, Usuarios, etc. En ella deberían de figurar los servicios y rutas que agregamos con cURL. 



Dashboard Services



Vamos a crear una key_auth, por motivos didácticos vamos a realizarlo por linea de comando y revisar como impacta en el Dashboard.



Creación de key-auth



Creacion de key-auth



Acá vemos que para poder consultar el Servicio API_Usuario sera necesario una llave.







Vamos a ver que nos responde, postman, al querer consultar nuestra API pero sin nuestra llave.



GET sin Key



Como se puede observar, ya no podremos realizar la consulta sin nuestra llave de autorización. Por eso vamos a averiguarla para asi agregarla en la consulta.



Consulta de key-auth en usuario_consultas



Nuestra key-auth es: apikey: 6xEJHFA7kONRagDMwaWdtQ2kjlPk2qZA



GET con --header 'apikey'



¡Excelente! Ahora si podemos consultar nuestra API, pero con seguridad. Realizamos la misma acción, vía postman.



postman



¡Perfecto! Funciona, todo. Mientras tanto, en nuestro servidor Flask, vemos el registro de las consultas.



Servidor API



¡Hay muchos plugins para agregar y jugar! Espero les sirva. Algo tan importante, como esto, debe estar controlado y monitoreado, siempre.



Saludos!

