---
title: "Seguridad de la Informacion  Agile a Escala"
date: "2020-03-23 00:30:07"
slug: "Seguridad de la Informacion  Agile a Escala"
image: "Insert Image URL Here"
---


Les dejo esta charla sobre Agile a Escala que dimos con los chicos de  Les dejo esta charla sobre Agile a Escala que dimos con los chicos de ISC2, capitulo Argentina. Como nos estamos organizando, las cblundstoneprezzi lecopavillon donkeywinkekatze fracominaoutlet marellasaldi scarpeovye loevenichhut ovyeshop negozigeox donkeyluckycat ovyeshop maisenzashop loevenichmutze and-camicie legioiedigeaeremonias que tenemos planteadas y la implementación de Security Champion. ISC2, capitulo Argentina. Como nos estamos organizando, las ceremonias que tenemos planteadas y la implementación de Security Champion.




https://www.youtube.com/watch?v=7wMLuK8FUk8
Link a YouTube

